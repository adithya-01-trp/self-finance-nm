package com.example.bottomnav.modelClasses

data class goalModel(
    var goalId : String? = null,
    var goalName: String? = null,
    var goalDescription: String? = null
)