package com.example.bottomnav

import android.icu.util.CurrencyAmount
import java.util.Date

data class expenseData(var name:String,var dueDate: String,var amount: String)
